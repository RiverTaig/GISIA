define(function ( ) {
    var privateValue = 0;
    return {
        
        helloWorld : function () {
            console.log("");
        }
    };
});